export const Mul=(props)=>{
    return(props.first*props.second);
}