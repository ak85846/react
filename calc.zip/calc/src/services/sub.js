export const Sub=(props)=>{
    return(props.first-props.second);
}