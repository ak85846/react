export const Div=(props)=>{
    return(props.first/props.second);
}