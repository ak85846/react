export const Cle=(props)=>{
    return(props.first+props.second);
}