export const Add=(props)=>{
    console.log()
    return(props.first+props.second);
}