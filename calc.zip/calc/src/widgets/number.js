import TextField from '@mui/material/TextField';


export const TextBox=(props)=>{
    const PlaceHolder=`type ${props.label} here`;
    return (
    <div>
        <label>{props.label}</label>
        &nbsp;
        <TextField onChange={props.fn} id="filled-basic" placeholder={PlaceHolder} label={props.label} variant="filled" />
    </div>
    );
}
