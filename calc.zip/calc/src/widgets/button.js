import Button from '@mui/material/Button';
import React from 'react';
export const Operation=({props})=>{

    return (
        <React.Fragment>
    <Button onClick={props.fn}   color={props.color} variant="contained">{props.label}</Button>
    &nbsp;
    </React.Fragment>
    );
}
