import React, { useState } from "react";
import { TextBox } from "../widgets/number";
import { Operation } from "../widgets/button";
import { Title } from "../widgets/Title";

import {Add} from "../services/add";
import { Sub } from "../services/sub";
import { Mul } from "../services/mul";
import { Div } from "../services/div";
import { Cle } from "../services/cle";
export const Calc=()=>{
    var FirstNum;
    var SecondNum;
    // const [res,]=useState('');
const takeFirstNum=(event)=>{
    FirstNum=event.target.value;
    console.log(FirstNum)
}
const takeSecondNum=(event)=>{
    SecondNum=event.target.value;
}
return(
<React.Fragment>
<TextBox fn={takeFirstNum} label="First Num"/>
<TextBox fn={takeSecondNum} label="Second Num"/>
<Operation fn={Add} label="+"/>
{/* <Operation value={FirstNum, SecondNum} label="+"/> */}

<Operation fn={Sub} label="-"/>
<Operation fn={Mul} label="*"/>
<Operation fn={Div} label="/"/>
<Operation fn={Cle} label="Clear All"/>
<Title result="hello" />
</React.Fragment>
);
}